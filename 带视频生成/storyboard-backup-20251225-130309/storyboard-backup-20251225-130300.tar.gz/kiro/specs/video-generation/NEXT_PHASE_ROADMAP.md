# 🚀 下一阶段实现路线图

**版本**: v2.0  
**目标**: 完成视频编辑、余额监控和角色管理功能  
**预计周期**: 2-3 周

---

## 📋 Phase 1: 视频编辑功能 (Remix)

**优先级**: 🔴 高  
**预计工作量**: 2-3 小时  
**目标完成**: 2024-12-25

### 需求分析

用户故事：作为分镜创作者，我想能够编辑已生成的视频，通过修改提示词来扩展或改进视频内容。

### 实现清单

#### 1. 创建视频编辑对话框组件
- [ ] 创建 `components/VideoEditDialog.tsx`
- [ ] 显示原视频预览
- [ ] 显示编辑提示词输入框
- [ ] 显示"应用编辑"和"取消"按钮
- [ ] 支持中英文界面

**代码框架**:
```typescript
interface VideoEditDialogProps {
  videoUrl: string;
  taskId: string;
  onApply: (editPrompt: string) => Promise<void>;
  onCancel: () => void;
  lang?: 'zh' | 'en';
}

export default function VideoEditDialog({
  videoUrl,
  taskId,
  onApply,
  onCancel,
  lang = 'zh'
}: VideoEditDialogProps) {
  const [editPrompt, setEditPrompt] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  
  // 实现编辑逻辑
}
```

#### 2. 更新 VideoWindow 组件
- [ ] 添加"编辑"按钮
- [ ] 点击编辑按钮打开编辑对话框
- [ ] 编辑完成后自动刷新视频

**修改位置**: `components/VideoWindow.tsx`

#### 3. 实现 Remix API 调用
- [ ] 在 `videoService.ts` 中添加 `remixVideo()` 函数
- [ ] 构建 POST 请求到 `/v1/videos/{task_id}/remix`
- [ ] 实现状态轮询机制
- [ ] 处理错误响应

**API 端点**:
```
POST {Base_URL}/v1/videos/{task_id}/remix
Content-Type: application/json

{
  "prompt": "编辑提示词"
}
```

#### 4. 集成到 App.tsx
- [ ] 添加编辑视频的处理函数
- [ ] 将编辑函数传递给 VideoWindow 组件
- [ ] 处理编辑完成后的状态更新

### 测试清单
- [ ] 编辑对话框正常显示
- [ ] 编辑提示词能正确提交
- [ ] 视频编辑完成后自动刷新
- [ ] 错误处理正确
- [ ] 中英文界面正常

---

## 📊 Phase 2: 用户余额监控

**优先级**: 🟡 中  
**预计工作量**: 1-2 小时  
**目标完成**: 2024-12-25

### 需求分析

用户故事：作为分镜创作者，我想能够查看我的 API 余额，以便了解还能生成多少视频。

### 实现清单

#### 1. 创建余额显示组件
- [ ] 创建 `components/BalanceDisplay.tsx`
- [ ] 显示当前余额/总配额
- [ ] 显示已使用配额
- [ ] 显示剩余配额
- [ ] 支持中英文

**代码框架**:
```typescript
interface BalanceInfo {
  total_quota: number;
  used_quota: number;
  remaining_quota: number;
}

interface BalanceDisplayProps {
  balance: BalanceInfo | null;
  isLoading: boolean;
  onRefresh: () => void;
  lang?: 'zh' | 'en';
}
```

#### 2. 实现余额查询服务
- [ ] 在 `videoService.ts` 中添加 `getBalance()` 函数
- [ ] 调用 GET `/v1/token/quota` 端点
- [ ] 处理响应数据
- [ ] 实现错误处理

**API 端点**:
```
GET {Base_URL}/v1/token/quota
Authorization: Bearer {API_Key}
```

#### 3. 集成到 App.tsx
- [ ] 在应用初始化时查询余额
- [ ] 定期刷新余额（每 5 分钟）
- [ ] 视频生成后刷新余额
- [ ] 余额不足时禁用生成按钮

#### 4. 添加余额警告
- [ ] 余额不足时显示警告
- [ ] 在生成视频按钮旁显示余额信息
- [ ] 支持点击查看详细信息

### 测试清单
- [ ] 余额查询正常工作
- [ ] 余额显示正确
- [ ] 定期刷新正常
- [ ] 余额不足时正确禁用按钮
- [ ] 错误处理正确

---

## 👤 Phase 3: 角色创建与管理

**优先级**: 🟡 中  
**预计工作量**: 4-6 小时  
**目标完成**: 2024-12-26

### 需求分析

用户故事：作为分镜创作者，我想能够从生成的视频中提取角色，并在其他视频中重复使用这些角色。

### 实现清单

#### 1. 创建角色创建对话框
- [ ] 创建 `components/CharacterCreationDialog.tsx`
- [ ] 显示视频预览
- [ ] 显示时间轴选择器
- [ ] 支持 1-3 秒时间范围选择
- [ ] 显示"创建"和"取消"按钮

**代码框架**:
```typescript
interface CharacterCreationDialogProps {
  videoUrl: string;
  taskId: string;
  onCreate: (timeRange: [number, number]) => Promise<void>;
  onCancel: () => void;
  lang?: 'zh' | 'en';
}
```

#### 2. 创建角色列表组件
- [ ] 创建 `components/CharacterList.tsx`
- [ ] 显示已创建的角色列表
- [ ] 显示角色缩略图
- [ ] 支持删除角色
- [ ] 支持复制角色 ID

#### 3. 实现角色 API 集成
- [ ] 在 `videoService.ts` 中添加 `createCharacter()` 函数
- [ ] 调用 POST `/sora/v1/characters` 端点
- [ ] 处理响应数据
- [ ] 实现错误处理

**API 端点**:
```
POST {Base_URL}/sora/v1/characters
Content-Type: application/json

{
  "from_task": "{task_id}",
  "start_time": 0,
  "end_time": 3
}
```

#### 4. 集成到 VideoWindow 组件
- [ ] 添加"创建角色"按钮
- [ ] 点击按钮打开角色创建对话框
- [ ] 创建完成后显示成功提示

#### 5. 集成到 VideoGenDialog 组件
- [ ] 在提示词输入框中支持 @ 符号
- [ ] 显示已创建角色列表
- [ ] 支持选择角色插入提示词
- [ ] 格式：`@{角色Username}`

#### 6. 实现角色存储
- [ ] 在 localStorage 中存储角色信息
- [ ] 支持角色列表持久化
- [ ] 支持角色删除

### 测试清单
- [ ] 角色创建对话框正常显示
- [ ] 时间轴选择器正常工作
- [ ] 角色创建 API 调用正确
- [ ] 角色列表显示正确
- [ ] 角色在提示词中正确插入
- [ ] 角色信息正确保存和加载

---

## 🔔 Phase 4: WebHook 配置

**优先级**: 🟢 低  
**预计工作量**: 3-4 小时  
**目标完成**: 2024-12-27

### 需求分析

用户故事：作为分镜创作者，我想能够配置 WebHook 地址，以便在视频生成完成时接收通知。

### 实现清单

#### 1. 创建 WebHook 配置组件
- [ ] 在 KeySelection 组件中添加 WebHook 配置选项
- [ ] 支持输入 WebHook 地址
- [ ] 支持测试 WebHook
- [ ] 支持启用/禁用 WebHook

#### 2. 实现 WebHook 接收端点
- [ ] 创建后端 API 端点接收 WebHook
- [ ] 验证 WebHook 签名
- [ ] 处理 WebHook 事件
- [ ] 更新视频状态

#### 3. 集成到视频生成流程
- [ ] 在生成视频时传递 WebHook 地址
- [ ] 接收 WebHook 通知
- [ ] 自动更新视频窗口状态
- [ ] 显示生成完成通知

#### 4. 实现备选轮询机制
- [ ] 如果 WebHook 失败，自动切换到轮询
- [ ] 定期检查视频状态
- [ ] 状态更新时自动刷新

### 测试清单
- [ ] WebHook 配置正常保存
- [ ] WebHook 测试正常工作
- [ ] WebHook 通知正确接收
- [ ] 视频状态正确更新
- [ ] 备选轮询机制正常工作

---

## 🎨 Phase 5: 隐私模式和水印

**优先级**: 🟢 低  
**预计工作量**: 1-2 小时  
**目标完成**: 2024-12-27

### 需求分析

用户故事：作为分镜创作者，我想能够配置视频的隐私设置和水印选项。

### 实现清单

#### 1. 添加隐私模式选项
- [ ] 在 VideoGenDialog 中添加隐私模式复选框
- [ ] 显示隐私模式说明
- [ ] 支持启用/禁用隐私模式

#### 2. 添加水印选项
- [ ] 在 VideoGenDialog 中添加水印复选框
- [ ] 显示水印说明
- [ ] 支持启用/禁用水印

#### 3. 集成到 API 调用
- [ ] 在生成视频时传递 private 参数
- [ ] 在生成视频时传递 watermark 参数
- [ ] 处理隐私模式的限制

### 测试清单
- [ ] 隐私模式选项正常显示
- [ ] 水印选项正常显示
- [ ] 参数正确传递给 API
- [ ] 隐私模式限制正确应用

---

## 📅 实现时间表

| Phase | 功能 | 预计工作量 | 目标完成 | 状态 |
|-------|------|----------|--------|------|
| 1 | 视频编辑 (Remix) | 2-3 小时 | 2024-12-25 | ⏳ 待开始 |
| 2 | 用户余额监控 | 1-2 小时 | 2024-12-25 | ⏳ 待开始 |
| 3 | 角色创建与管理 | 4-6 小时 | 2024-12-26 | ⏳ 待开始 |
| 4 | WebHook 配置 | 3-4 小时 | 2024-12-27 | ⏳ 待开始 |
| 5 | 隐私模式和水印 | 1-2 小时 | 2024-12-27 | ⏳ 待开始 |

**总计**: 11-17 小时  
**预计完成**: 2024-12-27

---

## 🔧 技术栈

- **前端框架**: React + TypeScript
- **UI 库**: Tailwind CSS
- **状态管理**: React Hooks
- **HTTP 客户端**: Fetch API
- **存储**: localStorage

---

## 📚 相关文档

- [requirements.md](./requirements.md) - 完整需求文档
- [design.md](./design.md) - 架构设计文档
- [API_INTEGRATION_GUIDE.md](./API_INTEGRATION_GUIDE.md) - API 集成指南
- [CURRENT_STATUS.md](./CURRENT_STATUS.md) - 当前实现状态

---

## 💡 实现建议

### 1. 代码组织
- 每个新功能创建独立的组件文件
- 在 `videoService.ts` 中集中管理 API 调用
- 在 `types.ts` 中定义所有类型

### 2. 错误处理
- 为每个 API 调用添加完整的错误处理
- 显示用户友好的错误信息
- 记录详细的错误日志

### 3. 用户体验
- 显示加载状态
- 提供进度反馈
- 支持操作取消
- 显示成功/失败提示

### 4. 测试
- 为每个新功能编写单元测试
- 进行集成测试
- 测试错误场景

---

## 🎯 成功标准

- ✅ 所有功能按时完成
- ✅ 代码质量达到标准
- ✅ 用户体验良好
- ✅ 文档完整
- ✅ 测试覆盖率 > 80%

---

**版本**: v2.0  
**最后更新**: 2024-12-24  
**下一步**: 开始 Phase 1 实现

